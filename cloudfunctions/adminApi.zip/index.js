// 管理员 API 云函数
// 支持 HTTP 触发，用于 Web 后台直接访问

const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

// 主入口函数
exports.main = async (event, context) => {
  // 腾讯云 HTTP 触发的 event 结构
  // {
  //   httpMethod: 'POST',
  //   headers: {...},
  //   body: '{"action":"list",...}',  // JSON 字符串
  //   queryStringParameters: {...}
  // }
  
  console.log('HTTP 方法:', event.httpMethod);
  console.log('Headers:', JSON.stringify(event.headers));
  console.log('Body 原始:', event.body);
  
  let params = {};
  
  // 处理 POST 请求
  if (event.httpMethod === 'POST') {
    try {
      params = JSON.parse(event.body || '{}');
    } catch (e) {
      console.error('解析 body 失败:', e);
      params = {};
    }
  }
  // 处理 GET 请求
  else if (event.httpMethod === 'GET') {
    params = event.queryStringParameters || {};
  }
  // 云函数直接调用
  else {
    params = event;
  }
  
  console.log('解析后的 params:', JSON.stringify(params));
  
  const action = params.action;
  const data = params.data;
  const members = params.members;
  
  try {
    switch (action) {
      case 'list':
        return await listMembers(params);
      case 'get':
        return await getMember(data);
      case 'create':
        return await createMember(data);
      case 'update':
        return await updateMember(data);
      case 'delete':
        return await deleteMember(data);
      case 'batchImport':
        return await batchImportMembers(members);
      case 'clearAll':
        return await clearAllMembers();
      case 'getCount':
        return await getMembersCount();
      case 'batchUpdateDetails':
        return await batchUpdateDetails(params);
      default:
        return { success: false, message: '未知操作' };
    }
  } catch (err) {
    console.error('操作失败:', err);
    return { success: false, message: err.message };
  }
};

// 获取成员列表
async function listMembers(params) {
  const { branch, generation, page = 1, pageSize = 20 } = params;
  
  let query = db.collection('members');
  
  if (branch) {
    query = query.where({ branch });
  }
  if (generation) {
    query = query.where({ generation });
  }
  
  const countResult = await query.count();
  const total = countResult.total;
  
  const { data } = await query
    .orderBy('generation', 'asc')
    .skip((page - 1) * pageSize)
    .limit(pageSize)
    .get();
  
  return {
    success: true,
    data,
    total
  };
}

// 获取单个成员
async function getMember(data) {
  const { _id } = data;
  const { data: member } = await db.collection('members').doc(_id).get();
  return {
    success: !!member,
    data: member
  };
}

// 创建成员
async function createMember(data) {
  const result = await db.collection('members').add({
    data: {
      ...data,
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }
  });
  return {
    success: true,
    data: { _id: result._id }
  };
}

// 更新成员
async function updateMember(data) {
  const { _id, ...updateData } = data;
  await db.collection('members').doc(_id).update({
    data: {
      ...updateData,
      updatedAt: db.serverDate()
    }
  });
  return { success: true };
}

// 删除成员
async function deleteMember(data) {
  const { _id } = data;
  await db.collection('members').doc(_id).remove();
  return { success: true };
}

// 批量导入
async function batchImportMembers(members) {
  if (!members || !Array.isArray(members) || members.length === 0) {
    return { success: false, message: '没有数据' };
  }
  
  const results = [];
  const errors = [];
  let imported = 0;
  
  // 分批处理
  const batchSize = 50;
  for (let i = 0; i < members.length; i += batchSize) {
    const batch = members.slice(i, i + batchSize);
    
    for (const member of batch) {
      try {
        const { _id, createdAt, updatedAt, ...cleanMember } = member;
        
        await db.collection('members').add({
          data: {
            ...cleanMember,
            createdAt: db.serverDate(),
            updatedAt: db.serverDate()
          }
        });
        
        imported++;
      } catch (err) {
        errors.push({
          name: member.name,
          error: err.message
        });
      }
    }
  }
  
  return {
    success: errors.length === 0,
    imported,
    failed: errors.length,
    errors
  };
}

// 清空所有数据
async function clearAllMembers() {
  const { data } = await db.collection('members').get();
  
  const deletePromises = data.map(doc => {
    return db.collection('members').doc(doc._id).remove();
  });
  
  await Promise.all(deletePromises);
  
  return {
    success: true,
    deletedCount: data.length
  };
}

// 获取数量
async function getMembersCount() {
  const result = await db.collection('members').count();
  return {
    success: true,
    count: result.total
  };
}

// 批量更新族人详细信息
async function batchUpdateDetails(params) {
  const { memberDetails } = params;
  
  if (!memberDetails || typeof memberDetails !== 'object') {
    return { success: false, message: '请提供 memberDetails 数据' };
  }
  
  const results = {
    success: [],
    notFound: [],
    failed: []
  };
  
  const names = Object.keys(memberDetails);
  
  for (const name of names) {
    try {
      const details = memberDetails[name];
      
      // 查询该族人
      const { data: members } = await db.collection('members')
        .where({
          name: name
        })
        .get();
      
      if (members.length === 0) {
        results.notFound.push(name);
        continue;
      }
      
      const member = members[0];
      
      // 准备更新数据
      const updateData = {};
      
      if (details.gender) updateData.gender = details.gender;
      if (details.education) {
        updateData.education = details.education.map(e => ({
          degree: typeof e === 'string' ? e : (e.degree || e),
          school: typeof e === 'object' ? (e.school || '') : '',
          major: typeof e === 'object' ? (e.major || '') : ''
        }));
      }
      if (details.positions) {
        updateData.positions = details.positions.map((p, index) => ({
          title: p.title || p,
          organization: p.organization || '',
          level: p.level || '',
          isCurrent: p.isCurrent || false,
          isDefault: index === details.positions.length - 1
        }));
      }
      if (details.residence) updateData.residence = details.residence;
      if (details.honors) {
        updateData.honors = details.honors.map(h => ({
          type: h.type || '',
          title: typeof h === 'string' ? h : (h.title || ''),
          level: h.level || '',
          year: h.year || null,
          description: h.description || ''
        }));
      }
      
      // 更新数据库
      await db.collection('members')
        .doc(member._id)
        .update({
          data: {
            ...updateData,
            updatedAt: db.serverDate()
          }
        });
      
      results.success.push(name);
      
      // 添加延迟避免频率限制
      await new Promise(resolve => setTimeout(resolve, 100));
      
    } catch (err) {
      console.error(`更新 ${name} 失败:`, err);
      results.failed.push({ name, error: err.message });
    }
  }
  
  return {
    success: true,
    message: `更新完成：成功 ${results.success.length}，未找到 ${results.notFound.length}，失败 ${results.failed.length}`,
    data: results
  };
}
